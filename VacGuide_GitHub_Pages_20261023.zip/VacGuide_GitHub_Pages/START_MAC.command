#!/bin/sh
cd "$(dirname "$0")" || exit 1
printf '%s\n' 'Open http://127.0.0.1:8080 in your browser.' 'Keep this window open. Press Control+C to stop.'
python3 -m http.server 8080 --bind 127.0.0.1 --directory dist
