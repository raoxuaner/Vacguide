# VacGuide Studio — GitHub Pages edition

VacGuide 几何设计 GUI v0.1。此包包含现有网站的完整前端、测试和 GitHub Pages 自动部署配置。应用无运行时第三方依赖，无需 npm install 或构建。

## 在 GitHub 上部署

1. 在自己的 GitHub 账号中新建一个独立仓库，建议名称 `vacguide-studio`。
2. 解压本压缩包，把 `VacGuide_GitHub_Pages` **文件夹里面的内容**放到仓库根目录，分支使用 `main`。确认包括 `.github/workflows/deploy-pages.yml`；不要把整个外层文件夹多套一层上传。
3. 进入仓库 **Settings → Pages → Build and deployment → Source → GitHub Actions**。
4. 进入 **Actions → Deploy VacGuide Studio to GitHub Pages → Run workflow**，选择 `main` 后运行。之后更新 `main` 会自动重新部署。
5. 等待工作流成功，在 **Settings → Pages** 或部署记录中打开网站链接。

GitHub Free 的 Pages 支持公开仓库；私人仓库需要支持 Pages 的付费计划。普通个人账号的 Pages 网站公开访问，即使源仓库设为私人。按你希望的公开范围选择仓库设置。

GitHub 官方说明：
- https://docs.github.com/en/pages/getting-started-with-github-pages/creating-a-github-pages-site
- https://docs.github.com/en/pages/getting-started-with-github-pages/using-custom-workflows-with-github-pages

### 用 Git 上传（能完整包含隐藏的配置文件）

先在 GitHub 上创建空仓库，再在解压后的项目文件夹打开终端。把下面 `YOUR_USERNAME` 替换成自己的账号；仓库名称不同时也替换 `vacguide-studio`。Git 会通过你本机已有的凭证管理器或登录流程认证。

```sh
git init -b main
git add .
git commit -m "Add VacGuide Studio"
git remote add origin https://github.com/YOUR_USERNAME/vacguide-studio.git
git push -u origin main
```

随后按上面的第 3、4 步开启 Pages 并运行部署。

## 本地运行

需要 Python 3。Windows 双击 `START_WINDOWS.bat`；macOS 在终端执行 `sh START_MAC.command`。打开 http://127.0.0.1:8080 。关闭终端或按 Ctrl+C 结束。

也可以直接运行：

```sh
python3 -m http.server 8080 --bind 127.0.0.1 --directory dist
```

JavaScript 使用 ES modules，因此通过 HTTP 访问，不直接双击 `index.html`。

## 迁移已经保存的设计

旧站点的自动保存保存在旧网址对应的浏览器存储中。先在旧网站点击 **保存项目** 导出 JSON，再在新网站点击 **导入**。SVG、CSV 和装配指南仍在浏览器内生成下载。

## 当前功能

- 1–12 个关节的串联结构，独立矩形面片与 guide 示意。
- 局部目标角度、平面内/平面外旋转、方向和尺寸编辑。
- 可旋转的三维几何预览、平面装配视图、进度滑块。
- 两组时序规划预览、撤销/重做、本地自动保存。
- JSON 项目导入导出，毫米 SVG 装配参考、CSV 参数及可打印 HTML 装配指南。

## 模型说明

面片和 guide 是独立零件，通过胶带连接后整体置入气囊。本版本提供几何规划与示意动画；压力、膜、力、碰撞、回弹及加工约束需要实验与后续模型支持。Guide 图形是示意，SVG 是装配参考。A/B 是规划分组，实际独立驱动需要对应气路。当前面片模型为矩形；多边形面片与连接边编辑将属于后续功能。

## 项目结构

| 路径 | 用途 |
|---|---|
| `dist/index.html` | 网站入口 |
| `dist/style.css` | 界面样式 |
| `dist/app.js` | 界面与交互 |
| `dist/model.js` | 参数、项目状态和时序 |
| `dist/geometry.js` | 几何与投影 |
| `tests/` | 几何与状态测试 |
| `.github/workflows/deploy-pages.yml` | 测试并发布 `dist/` 到 GitHub Pages |

## 开发验证

需要 Node.js 20 或更新版本。在项目根目录执行 `npm test`。不需要安装依赖。GitHub Actions 也会在发布前运行这组测试。

本包对应 2026-10-23 的 v0.1 界面。是否已上线以 GitHub 的成功部署记录为准。
