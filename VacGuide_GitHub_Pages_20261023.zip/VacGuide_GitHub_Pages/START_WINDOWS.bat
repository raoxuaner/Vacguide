@echo off
cd /d "%~dp0"
echo Open http://127.0.0.1:8080 in your browser.
echo Keep this window open. Press Ctrl+C to stop.
where py >nul 2>nul
if %errorlevel% equ 0 (
  py -3 -m http.server 8080 --bind 127.0.0.1 --directory dist
) else (
  python -m http.server 8080 --bind 127.0.0.1 --directory dist
)
pause
