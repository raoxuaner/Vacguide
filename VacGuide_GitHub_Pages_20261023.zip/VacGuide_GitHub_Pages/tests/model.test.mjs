import test from 'node:test';
import assert from 'node:assert/strict';
import { preset, validateProject, channelFactor } from '../dist/model.js';

const clone = value => JSON.parse(JSON.stringify(value));
const near = (a, b, tolerance = 1e-9) => assert.ok(Math.abs(a - b) <= tolerance, `${a} differs from ${b}`);

test('each supported preset survives JSON export/import without losing design information', () => {
  for (const key of ['study', 'arch', 'wave']) {
    const project = preset(key);
    assert.deepEqual(validateProject(clone(project)), project);
  }
});

test('custom single-joint and twelve-joint projects are valid roundtrip states', () => {
  for (const count of [1, 12]) {
    const project = preset();
    project.preset = 'custom';
    project.joints = Array.from({ length: count }, (_, i) => ({
      id: `J${i + 1}`, angle: i * 10, plane: i % 2 ? 'in' : 'out',
      direction: i % 2 ? -1 : 1, group: i % 2 ? 'B' : 'A'
    }));
    project.notes = '测试：独立面片＋guide，胶带连接后装袋。';
    assert.deepEqual(validateProject(clone(project)), project);
  }
});

test('invalid schemas, versions, dimensions and joint parameters are rejected', () => {
  const changes = [
    p => { p.schema = 'different'; }, p => { p.version = 999; },
    p => { p.name = 'x'.repeat(61); }, p => { p.panelLength = '45'; },
    p => { p.panelLength = NaN; }, p => { p.span = Infinity; },
    p => { p.span = 0; }, p => { p.gap = 3.9; },
    p => { p.joints = []; }, p => { p.joints = Array(13).fill(p.joints[0]); },
    p => { p.joints[0].angle = 121; }, p => { p.joints[0].angle = -1; },
    p => { p.joints[0].angle = null; }, p => { p.joints[0].plane = 'unknown'; },
    p => { p.joints[0].group = 'C'; }, p => { p.joints[0].direction = 0; },
    p => { p.joints[0] = null; }, p => { p.timing = null; }
  ];
  for (const mutate of changes) {
    const p = preset(); mutate(p); assert.throws(() => validateProject(p));
  }
  assert.throws(() => validateProject(null));
});

test('validator canonicalizes IDs without mutating original imported input', () => {
  const p = preset(); p.joints[0].id = '<untrusted>'; p.extra = 'ignore';
  const before = clone(p);
  const output = validateProject(p);
  assert.deepEqual(p, before);
  assert.equal(output.joints[0].id, 'J1');
  assert.equal(output.extra, undefined);
});

test('invalid timing windows are rejected and exactly 0.2 seconds is accepted', () => {
  for (const timing of [
    { start: -1, end: 4 }, { start: 1, end: 1 },
    { start: 2, end: 1 }, { start: 0, end: 8.1 },
    { start: 0, end: 0.199 }, { start: 1, end: NaN }
  ]) {
    const p = preset(); p.timing.A = timing;
    assert.throws(() => validateProject(p));
  }
  const p = preset(); p.timing.A = { start: 1, end: 1.2 };
  assert.deepEqual(validateProject(p).timing.A, p.timing.A);
});

test('long animation window ramps up, holds, and releases within zero to one', () => {
  const channel = { start: 1, end: 4 };
  near(channelFactor(0, channel), 0);
  near(channelFactor(1, channel), 0);
  near(channelFactor(1.4, channel), .5);
  near(channelFactor(2, channel), 1);
  near(channelFactor(4, channel), 1);
  near(channelFactor(4.4, channel), .5);
  near(channelFactor(5, channel), 0);
  for (let i = 0; i <= 60; i++) assert.ok(channelFactor(i / 10, channel) >= 0 && channelFactor(i / 10, channel) <= 1);
});

test('short valid animation window cannot jump upward when release starts', () => {
  const channel = { start: 0, end: .2 };
  const atRelease = channelFactor(.2, channel);
  const afterRelease = channelFactor(.200001, channel);
  assert.ok(afterRelease <= atRelease + 1e-8, `release jumped from ${atRelease} to ${afterRelease}`);
  assert.ok(Math.abs(afterRelease - atRelease) < 1e-5, 'release must be continuous');
  near(channelFactor(1.1, channel), 0);
});
