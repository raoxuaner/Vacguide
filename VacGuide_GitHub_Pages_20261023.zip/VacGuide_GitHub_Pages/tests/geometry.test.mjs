import test from 'node:test';
import assert from 'node:assert/strict';
import { buildAssembly, projectPoint } from '../dist/geometry.js';

const base = () => ({ panelLength: 45, span: 30, gap: 8, joints: [20, 30, 50, 70].map((angle, i) => ({ id: `J${i + 1}`, angle, plane: 'out', direction: 1, group: i < 2 ? 'A' : 'B' })) });
const distance = (a, b) => Math.hypot(...a.map((v, i) => v - b[i]));
const almost = (actual, expected) => assert.ok(Math.abs(actual - expected) < 1e-8, `${actual} != ${expected}`);

test('flat state contains separate, correctly spaced panels and joint pivots', () => {
  const result = buildAssembly(base(), 0);
  assert.equal(result.panels.length, 5);
  assert.equal(result.joints.length, 4);
  for (let i = 0; i < 5; i++) {
    for (const p of result.panels[i].vertices) almost(p[2], 0);
    almost(result.panels[i].vertices[0][0], i * 53);
  }
  almost(result.joints[0].origin[0], 49);
  almost(result.panels[4].vertices[1][0], 257);
});

test('positive out-of-plane angle lifts downstream panels and preserves rigid dimensions', () => {
  const project = base();
  project.joints = [project.joints[0]];
  project.joints[0].angle = 90;
  const { panels, joints } = buildAssembly(project);
  almost(panels[1].vertices[1][2] - panels[1].vertices[0][2], 45);
  almost(distance(panels[1].vertices[0], panels[1].vertices[1]), 45);
  almost(distance(panels[1].vertices[1], panels[1].vertices[2]), 30);
  almost(distance(joints[0].points[0], joints[0].points[1]), 30);
});

test('editing J2 preserves upstream panels and pivots but changes downstream geometry', () => {
  const before = base(), after = base();
  after.joints[1].angle = 50;
  const a = buildAssembly(before), b = buildAssembly(after);
  assert.deepEqual(a.panels.slice(0, 2), b.panels.slice(0, 2));
  assert.deepEqual(a.joints[1].origin, b.joints[1].origin);
  assert.notDeepEqual(a.panels[2].vertices, b.panels[2].vertices);
  assert.notDeepEqual(a.panels[4].vertices, b.panels[4].vertices);
});

test('in-plane chain remains in XY plane while positive angle turns toward +Y', () => {
  const project = base();
  project.joints.forEach(j => { j.plane = 'in'; });
  const { panels } = buildAssembly(project);
  for (const panel of panels) for (const p of panel.vertices) almost(p[2], 0);
  assert.ok(panels[1].center[1] > 0);
});

test('mixed-axis chain remains rigid with finite geometry and orthonormal joint axes', () => {
  const project = base();
  project.joints[1].plane = 'in';
  project.joints[2].direction = -1;
  const { panels, joints } = buildAssembly(project, 0.71);
  for (const panel of panels) {
    almost(distance(panel.vertices[0], panel.vertices[1]), 45);
    almost(distance(panel.vertices[1], panel.vertices[2]), 30);
    for (const p of panel.vertices) assert.ok(p.every(Number.isFinite));
  }
  for (const j of joints) almost(Math.hypot(...j.axis), 1);
});

test('channel factors affect assigned joints only, without implying measured pressure response', () => {
  const result = buildAssembly(base(), 1, { A: 1, B: 0 });
  assert.deepEqual(result.joints.map(j => j.angle), [20, 30, 0, 0]);
  const flat = buildAssembly(base(), 0, { A: 1, B: 1 });
  assert.deepEqual(flat.joints.map(j => j.angle), [0, 0, 0, 0]);
});

test('projection has an exact top view and a finite default view', () => {
  const top = projectPoint([10, 20, 30], { yaw: 0, pitch: 90, scale: 2, cx: 100, cy: 100 });
  almost(top.x, 120); almost(top.y, 140); almost(top.depth, 30);
  assert.ok(Object.values(projectPoint([1, 2, 3])).every(Number.isFinite));
});

test('zero joints yields one panel; invalid dimensions and nonfinite input are rejected', () => {
  assert.equal(buildAssembly({ ...base(), joints: [] }).panels.length, 1);
  assert.throws(() => buildAssembly({ ...base(), span: 0 }), RangeError);
  assert.throws(() => buildAssembly(base(), NaN), TypeError);
});
